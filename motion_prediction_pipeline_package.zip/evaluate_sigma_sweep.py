#!/usr/bin/env python3
"""Fine-Grained Sigma Sweep Evaluation for Motion Prediction V17 X-Large.

Tests sigma in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0]
Across all 24,097 validation scenes (353,607 targets).
"""
from __future__ import annotations

import argparse, os, sys, time
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.cached_collate_v13 import CachedWindowCollateV13, try_cached_loader_v13
from src.train_motion_prediction_v17 import MotionPredictorV17
from train_motion_prediction_v2_awta import configure_runtime, make_loader, move_samples
from train_motion_prediction_v17 import model_forward_v17
from evaluate_v16_nms import apply_soft_density_nms


def run_sigma_sweep(
    model: torch.nn.Module,
    val_loader: torch.utils.data.DataLoader,
    device: torch.device,
    amp_dtype: torch.dtype = torch.bfloat16,
    sigma_list: list[float] = [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0, 5.5, 6.0],
):
    model.eval()

    total_targets = 0
    total_minade6 = 0.0
    total_minfde6 = 0.0
    total_minade1_raw = 0.0
    total_minfde1_raw = 0.0
    correct_pick_raw = 0

    density_results = {
        f"s{s:.1f}": {"ade1": 0.0, "fde1": 0.0, "pick": 0} for s in sigma_list
    }
    blend_results = {
        f"s{s:.1f}": {"ade1": 0.0, "fde1": 0.0} for s in sigma_list
    }

    print("=" * 85)
    print(f" SIGMA SWEEP EVALUATION: {sigma_list}")
    print("=" * 85)

    t0 = time.time()
    with torch.no_grad():
        for step, samples in enumerate(val_loader, start=1):
            samples = move_samples(samples, device)
            with torch.amp.autocast("cuda", dtype=amp_dtype):
                pred_2, goals_2, logits_2, pred_1, goals_1 = model_forward_v17(model, samples)

            future = samples["future"]  # [B, 80, 2]
            f_valid = samples["future_valid"]  # [B, 80]
            B = future.shape[0]
            total_targets += B

            # ADE & FDE for all 6 modes: [B, 6]
            diff = pred_2 - future.unsqueeze(1)  # [B, 6, 80, 2]
            dist_per_step = torch.linalg.vector_norm(diff, dim=-1)  # [B, 6, 80]
            valid_mask = f_valid.unsqueeze(1).float()  # [B, 1, 80]
            valid_counts = valid_mask.sum(dim=-1).clamp_min(1.0)  # [B, 1]

            ade_modes = (dist_per_step * valid_mask).sum(dim=-1) / valid_counts  # [B, 6]
            fde_modes = dist_per_step[:, :, -1]  # [B, 6]

            # Best ground truth mode (Winner)
            best_gt_mode = ade_modes.argmin(dim=-1)  # [B]
            total_minade6 += ade_modes.min(dim=-1).values.sum().item()
            total_minfde6 += fde_modes.gather(1, best_gt_mode.unsqueeze(-1)).squeeze(-1).sum().item()

            # Raw Top-1 Selection (Argmax)
            top1_raw = logits_2.argmax(dim=-1)  # [B]
            total_minade1_raw += ade_modes.gather(1, top1_raw.unsqueeze(-1)).squeeze(-1).sum().item()
            total_minfde1_raw += fde_modes.gather(1, top1_raw.unsqueeze(-1)).squeeze(-1).sum().item()
            correct_pick_raw += (top1_raw == best_gt_mode).sum().item()

            # Sweep all sigma values
            for s in sigma_list:
                k = f"s{s:.1f}"
                # 1. Density Mode Selection (No Blending)
                _, mode_dens = apply_soft_density_nms(pred_2, logits_2, sigma=s, do_blend=False)
                density_results[k]["ade1"] += ade_modes.gather(1, mode_dens.unsqueeze(-1)).squeeze(-1).sum().item()
                density_results[k]["fde1"] += fde_modes.gather(1, mode_dens.unsqueeze(-1)).squeeze(-1).sum().item()
                density_results[k]["pick"] += (mode_dens == best_gt_mode).sum().item()

                # 2. Soft Density Cluster Blending
                blend_traj, _ = apply_soft_density_nms(pred_2, logits_2, sigma=s, do_blend=True)
                diff_blend = blend_traj - future
                dist_blend = torch.linalg.vector_norm(diff_blend, dim=-1)
                ade1_bl = (dist_blend * f_valid.float()).sum(dim=-1) / f_valid.float().sum(dim=-1).clamp_min(1.0)
                blend_results[k]["ade1"] += ade1_bl.sum().item()
                blend_results[k]["fde1"] += dist_blend[:, -1].sum().item()

            if step % 100 == 0 or step == len(val_loader):
                print(f"-> Evaluated [{step:03d}/{len(val_loader):03d}] batches ({total_targets:,} targets)...", flush=True)

    eval_sec = time.time() - t0
    m_minade6 = total_minade6 / total_targets
    m_minfde6 = total_minfde6 / total_targets
    m_ade1_raw = total_minade1_raw / total_targets
    m_fde1_raw = total_minfde1_raw / total_targets
    raw_pick = correct_pick_raw / total_targets
    err_raw = 0.5 * (m_minade6 + m_ade1_raw)

    print("\n" + "=" * 85)
    print(f" DETAILED SIGMA SWEEP REPORT ({total_targets:,} targets in {eval_sec:.1f}s)")
    print("=" * 85)
    print(f"-> Baseline (No NMS): minADE6={m_minade6:.4f}m | minADE1={m_ade1_raw:.4f}m | Pick={raw_pick*100:.2f}% | Error={err_raw:.4f}")
    print("-" * 85)
    print(f"{'Sigma (m)':<12} | {'Density minADE1':<15} | {'Pick Acc':<10} | {'Density Error':<14} | {'Blend minADE1':<14} | {'Blend Error':<12}")
    print("-" * 85)

    best_density_sigma = None
    best_density_err = 999.0
    best_blend_sigma = None
    best_blend_err = 999.0

    for s in sigma_list:
        k = f"s{s:.1f}"
        ade_d = density_results[k]["ade1"] / total_targets
        pick_d = density_results[k]["pick"] / total_targets
        err_d = 0.5 * (m_minade6 + ade_d)

        ade_b = blend_results[k]["ade1"] / total_targets
        err_b = 0.5 * (m_minade6 + ade_b)

        if err_d < best_density_err:
            best_density_err = err_d
            best_density_sigma = s

        if err_b < best_blend_err:
            best_blend_err = err_b
            best_blend_sigma = s

        marker_d = " 🏆" if err_d == best_density_err else ""
        print(f"σ = {s:4.1f} m     | {ade_d:.4f} m        | {pick_d*100:5.2f}%    | {err_d:.4f}{marker_d:<3}       | {ade_b:.4f} m       | {err_b:.4f}")

    print("=" * 85)
    print(f"🥇 BEST DENSITY SELECTION:  σ = {best_density_sigma:.1f} m  -->  Error Score = {best_density_err:.4f}")
    print(f"🥈 BEST CLUSTER BLENDING:   σ = {best_blend_sigma:.1f} m  -->  Error Score = {best_blend_err:.4f}")
    print("=" * 85)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", default=r"E:\motion_prediction\checkpoints\v17_xlarge\swa_model.pth")
    parser.add_argument("--cache-root", default=r"E:\motion_prediction\data\processed\prediction_pt_85k_v2_cache_v13")
    parser.add_argument("--batch-scenes", type=int, default=64)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--amp", default="bf16")
    args = parser.parse_args()

    configure_runtime(args.workers)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    amp_dtype = torch.bfloat16 if args.amp == "bf16" else (torch.float16 if args.amp == "fp16" else torch.float32)

    print(f"Loading V17 Model from: {args.ckpt}")
    model = MotionPredictorV17(hidden=768, modes=6, nhead=12, dropout=0.1).to(device)
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    model.load_state_dict(ckpt.get("model_state", ckpt))

    val_ds = try_cached_loader_v13(args.cache_root, "val", 0)
    val_collate = CachedWindowCollateV13(args.batch_scenes, False)
    val_loader = make_loader(val_ds, args.batch_scenes, args.workers, 4, False, val_collate, False)

    sigmas = [round(0.5 + i * 0.5, 1) for i in range(12)]  # 0.5, 1.0, ..., 6.0
    run_sigma_sweep(model, val_loader, device, amp_dtype, sigmas)


if __name__ == "__main__":
    main()
