#!/usr/bin/env python3
"""Diagnose Error Bottlenecks for Motion Prediction V17 X-Large.

Analyzes 353,607 validation targets across:
1. Agent Type (Vehicle / Pedestrian / Cyclist)
2. Motion State (Stationary / Turning / Straight / High Speed)
3. Time Horizon (1s, 3s, 5s, 8s ADE/FDE)
4. Winner vs Picked Gap Analysis (Where does the ADE1 penalty come from?)
"""
from __future__ import annotations

import argparse, os, sys, time
import numpy as np
import torch
import torch.nn.functional as F

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from src.cached_collate_v13 import CachedWindowCollateV13, try_cached_loader_v13
from src.train_motion_prediction_v17 import MotionPredictorV17
from train_motion_prediction_v2_awta import configure_runtime, make_loader, move_samples
from train_motion_prediction_v17 import model_forward_v17
from evaluate_v16_nms import apply_soft_density_nms


def analyze_bottlenecks(
    model: torch.nn.Module,
    val_loader: torch.utils.data.DataLoader,
    device: torch.device,
    amp_dtype: torch.dtype = torch.bfloat16,
    sigma: float = 2.5,
):
    model.eval()

    # Breakdown by Type: 0: Vehicle, 1: Pedestrian, 2: Cyclist
    types_stat = {
        "Vehicle (0)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0, "pick": 0},
        "Pedestrian (1)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0, "pick": 0},
        "Cyclist (2)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0, "pick": 0},
    }

    # Breakdown by Motion State
    motion_stat = {
        "Stationary (v < 0.5 m/s)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0},
        "Low Speed (0.5 <= v < 4 m/s)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0},
        "High Speed Cruise (v >= 4 m/s)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0},
        "Turning / Curving (|yaw_diff| > 0.15 rad)": {"count": 0, "ade6": 0.0, "ade1": 0.0, "fde6": 0.0, "fde1": 0.0},
    }

    # Breakdown by Time Horizon (1s=10st, 3s=30st, 5s=50st, 8s=80st)
    horizon_ade6 = {10: 0.0, 30: 0.0, 50: 0.0, 80: 0.0}
    horizon_ade1 = {10: 0.0, 30: 0.0, 50: 0.0, 80: 0.0}

    total_targets = 0
    t0 = time.time()

    with torch.no_grad():
        for step, samples in enumerate(val_loader, start=1):
            samples = move_samples(samples, device)
            with torch.amp.autocast("cuda", dtype=amp_dtype):
                pred_2, goals_2, logits_2, pred_1, goals_1 = model_forward_v17(model, samples)

            future = samples["future"]  # [B, 80, 2]
            f_valid = samples["future_valid"]  # [B, 80]
            type_idx = samples["type_idx"]  # [B]
            target_hist = samples["target_hist"]  # [B, 11, 5] (x, y, yaw, vx, vy)
            B = future.shape[0]
            total_targets += B

            # Compute ADE and FDE for all 6 modes: [B, 6]
            diff = pred_2 - future.unsqueeze(1)
            dist_per_step = torch.linalg.vector_norm(diff, dim=-1)  # [B, 6, 80]
            valid_mask = f_valid.unsqueeze(1).float()
            valid_counts = valid_mask.sum(dim=-1).clamp_min(1.0)
            ade_modes = (dist_per_step * valid_mask).sum(dim=-1) / valid_counts  # [B, 6]
            fde_modes = dist_per_step[:, :, -1]

            best_gt_mode = ade_modes.argmin(dim=-1)  # [B]
            min_ade6_b = ade_modes.min(dim=-1).values  # [B]
            min_fde6_b = fde_modes.gather(1, best_gt_mode.unsqueeze(-1)).squeeze(-1)  # [B]

            # Selected mode via Soft Density NMS (sigma=2.5)
            _, mode_picked = apply_soft_density_nms(pred_2, logits_2, sigma=sigma, do_blend=False)
            ade1_picked_b = ade_modes.gather(1, mode_picked.unsqueeze(-1)).squeeze(-1)  # [B]
            fde1_picked_b = fde_modes.gather(1, mode_picked.unsqueeze(-1)).squeeze(-1)  # [B]
            is_pick_correct = (mode_picked == best_gt_mode)

            # 1. Type Breakdown
            for t_val, t_name in enumerate(["Vehicle (0)", "Pedestrian (1)", "Cyclist (2)"]):
                mask_t = (type_idx == t_val)
                if mask_t.any():
                    cnt = mask_t.sum().item()
                    types_stat[t_name]["count"] += cnt
                    types_stat[t_name]["ade6"] += min_ade6_b[mask_t].sum().item()
                    types_stat[t_name]["ade1"] += ade1_picked_b[mask_t].sum().item()
                    types_stat[t_name]["fde6"] += min_fde6_b[mask_t].sum().item()
                    types_stat[t_name]["fde1"] += fde1_picked_b[mask_t].sum().item()
                    types_stat[t_name]["pick"] += is_pick_correct[mask_t].sum().item()

            # 2. Motion State Breakdown
            cur_speed = torch.linalg.vector_norm(target_hist[:, -1, 3:5], dim=-1)  # [B]
            past_yaw_diff = (target_hist[:, -1, 2] - target_hist[:, 0, 2]).abs()  # [B]

            stat_masks = {
                "Stationary (v < 0.5 m/s)": (cur_speed < 0.5),
                "Low Speed (0.5 <= v < 4 m/s)": ((cur_speed >= 0.5) & (cur_speed < 4.0)),
                "High Speed Cruise (v >= 4 m/s)": (cur_speed >= 4.0),
                "Turning / Curving (|yaw_diff| > 0.15 rad)": (past_yaw_diff > 0.15),
            }

            for m_name, m_mask in stat_masks.items():
                if m_mask.any():
                    cnt = m_mask.sum().item()
                    motion_stat[m_name]["count"] += cnt
                    motion_stat[m_name]["ade6"] += min_ade6_b[m_mask].sum().item()
                    motion_stat[m_name]["ade1"] += ade1_picked_b[m_mask].sum().item()
                    motion_stat[m_name]["fde6"] += min_fde6_b[m_mask].sum().item()
                    motion_stat[m_name]["fde1"] += fde1_picked_b[m_mask].sum().item()

            # 3. Horizon Breakdown (cumulative up to step t)
            for h in [10, 30, 50, 80]:
                val_h = valid_mask[:, :, :h]
                cnt_h = val_h.sum(dim=-1).clamp_min(1.0)
                ade_h_modes = (dist_per_step[:, :, :h] * val_h).sum(dim=-1) / cnt_h
                horizon_ade6[h] += ade_h_modes.min(dim=-1).values.sum().item()
                horizon_ade1[h] += ade_h_modes.gather(1, mode_picked.unsqueeze(-1)).squeeze(-1).sum().item()

            if step % 100 == 0 or step == len(val_loader):
                print(f"-> Evaluated [{step:03d}/{len(val_loader):03d}] batches...", flush=True)

    print("\n" + "=" * 90)
    print(f" 🔍 V17 X-LARGE COMPREHENSIVE ERROR BOTTLENECK DIAGNOSTIC REPORT ({total_targets:,} Targets)")
    print("=" * 90)

    # 1. Type Breakdown Table
    print("\n### 1. 객체 유형별 (Agent Type) 정밀 오차 분석")
    print("-" * 90)
    print(f"{'Agent Type':<16} | {'Count':<10} | {'Ratio':<7} | {'minADE6':<10} | {'minADE1':<10} | {'Pick Acc':<10} | {'Error Score':<12}")
    print("-" * 90)
    for t_name, stat in types_stat.items():
        cnt = stat["count"]
        if cnt == 0: continue
        ade6 = stat["ade6"] / cnt
        ade1 = stat["ade1"] / cnt
        pick = stat["pick"] / cnt * 100
        err = 0.5 * (ade6 + ade1)
        ratio = cnt / total_targets * 100
        print(f"{t_name:<16} | {cnt:<10,d} | {ratio:5.1f}% | {ade6:.4f}m    | {ade1:.4f}m    | {pick:5.2f}%     | {err:.4f}")

    # 2. Motion State Breakdown Table
    print("\n### 2. 주행 상태 및 시나리오별 (Motion Scenario) 오차 분석")
    print("-" * 90)
    print(f"{'Motion Scenario':<42} | {'Count':<9} | {'Ratio':<7} | {'minADE6':<10} | {'minADE1':<10} | {'Error Score':<12}")
    print("-" * 90)
    for m_name, stat in motion_stat.items():
        cnt = stat["count"]
        if cnt == 0: continue
        ade6 = stat["ade6"] / cnt
        ade1 = stat["ade1"] / cnt
        err = 0.5 * (ade6 + ade1)
        ratio = cnt / total_targets * 100
        print(f"{m_name:<42} | {cnt:<9,d} | {ratio:5.1f}% | {ade6:.4f}m    | {ade1:.4f}m    | {err:.4f}")

    # 3. Horizon Breakdown Table
    print("\n### 3. 예측 시간 구간별 (Prediction Time Horizon) 누적 오차 분석")
    print("-" * 90)
    print(f"{'Time Horizon':<20} | {'minADE6 (m)':<15} | {'minADE1 (m)':<15} | {'Error Score':<15} | {'누적 오차 기여율':<15}")
    print("-" * 90)
    for h, sec_label in zip([10, 30, 50, 80], ["1.0s (10 steps)", "3.0s (30 steps)", "5.0s (50 steps)", "8.0s (80 steps)"]):
        ade6 = horizon_ade6[h] / total_targets
        ade1 = horizon_ade1[h] / total_targets
        err = 0.5 * (ade6 + ade1)
        contrib = err / (0.5 * (horizon_ade6[80]/total_targets + horizon_ade1[80]/total_targets)) * 100
        print(f"{sec_label:<20} | {ade6:.4f} m        | {ade1:.4f} m        | {err:.4f}          | {contrib:5.1f}%")

    # 4. Error Gap (ADE6 vs ADE1)
    ov_ade6 = sum(stat["ade6"] for stat in types_stat.values()) / total_targets
    ov_ade1 = sum(stat["ade1"] for stat in types_stat.values()) / total_targets
    ov_err = 0.5 * (ov_ade6 + ov_ade1)
    gap = ov_ade1 - ov_ade6
    print("\n" + "=" * 90)
    print("### 4. 종합 오차 점수 성분 분해 (Error Score Decomposition)")
    print(f"  * 바닥 예측 오차 (minADE6) : {ov_ade6:.4f} m  (종합 점수의 {ov_ade6 / (2*ov_err) * 100:.1f}%)")
    print(f"  * 1등 선택 오차 (minADE1)  : {ov_ade1:.4f} m  (종합 점수의 {ov_ade1 / (2*ov_err) * 100:.1f}%)")
    print(f"  * 선택 오차 갭 (Gap)       : {gap:.4f} m  <--- 추가 감점의 핵심 원인!")
    print("=" * 90)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--ckpt", default=r"E:\motion_prediction\checkpoints\v17_xlarge\swa_model.pth")
    parser.add_argument("--cache-root", default=r"E:\motion_prediction\data\processed\prediction_pt_85k_v2_cache_v13")
    parser.add_argument("--batch-scenes", type=int, default=64)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--amp", default="bf16")
    parser.add_argument("--sigma", type=float, default=2.5)
    args = parser.parse_args()

    configure_runtime(args.workers)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    amp_dtype = torch.bfloat16 if args.amp == "bf16" else (torch.float16 if args.amp == "fp16" else torch.float32)

    print(f"Loading V17 SWA Model from: {args.ckpt}")
    model = MotionPredictorV17(hidden=768, modes=6, nhead=12, dropout=0.1).to(device)
    ckpt = torch.load(args.ckpt, map_location=device, weights_only=False)
    model.load_state_dict(ckpt.get("model_state", ckpt))

    val_ds = try_cached_loader_v13(args.cache_root, "val", 0)
    val_collate = CachedWindowCollateV13(args.batch_scenes, False)
    val_loader = make_loader(val_ds, args.batch_scenes, args.workers, 4, False, val_collate, False)

    analyze_bottlenecks(model, val_loader, device, amp_dtype, sigma=args.sigma)


if __name__ == "__main__":
    main()
